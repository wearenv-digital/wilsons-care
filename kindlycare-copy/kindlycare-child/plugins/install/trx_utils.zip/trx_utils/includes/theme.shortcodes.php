<?php
if (!function_exists('kindlycare_theme_shortcodes_setup')) {
	add_action( 'kindlycare_action_before_init_theme', 'kindlycare_theme_shortcodes_setup', 1 );
	function kindlycare_theme_shortcodes_setup() {
		add_filter('kindlycare_filter_googlemap_styles', 'kindlycare_theme_shortcodes_googlemap_styles');
	}
}


// Add theme-specific Google map styles
if ( !function_exists( 'kindlycare_theme_shortcodes_googlemap_styles' ) ) {
	function kindlycare_theme_shortcodes_googlemap_styles($list) {
		$list['simple']		= esc_html__('Simple', 'kindlycare');
		$list['greyscale']	= esc_html__('Greyscale', 'kindlycare');
		$list['inverse']	= esc_html__('Inverse', 'kindlycare');
		$list['light']	    = esc_html__('Light', 'kindlycare');
		return $list;
	}
}
?>